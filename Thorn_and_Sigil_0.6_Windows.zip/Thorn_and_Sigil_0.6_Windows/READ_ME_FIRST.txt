THORN & SIGIL 0.6 - THE LAST GATE

Extract the entire ZIP. Open the extracted folder and launch ThornAndSigil.exe.
Keep _internal beside the EXE. Python does not need to be installed.

Your first launch starts a fresh journey. Challenge the Briar Scout in Journey.
Gather materials, craft cards and equipment, and battle nine guardians.

Drag a hand card onto a highlighted lane, or click the card and then the lane.
Right-click a card or creature to inspect it. Invoke activates a creature's
ability in place of its next attack. Resolve clash advances combat.
1-7: select hand card. Enter: resolve clash. Escape: cancel. F11: fullscreen.
Scroll the mouse wheel to browse the Journey, recipes, and Field Guide.

The game saves automatically and resumes your progress the next time you play.
Each Windows account has its own save. The game runs offline.
Save location: %LOCALAPPDATA%\ThornAndSigil\save.json

Field Guide contains Import save, Export save, and Start new journey.
Starting over or importing keeps a separate backup of your previous journey.
You can import your older Wildforge JSON save through Import save.
Sound and reduced motion can be changed in the game.

Share feedback with the person who sent you the game: what happened, which
card or guardian was involved, and what you expected. A screenshot helps.
